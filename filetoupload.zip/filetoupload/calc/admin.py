from django.contrib import admin

# Register your models here.
from calc.models import UserProfile

admin.site.register(UserProfile)